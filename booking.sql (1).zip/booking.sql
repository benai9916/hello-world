-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 27, 2018 at 08:20 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `booking`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'ben', 'ben123'),
(2, 'akshay', '123');

-- --------------------------------------------------------

--
-- Table structure for table `book1`
--

CREATE TABLE `book1` (
  `id` int(11) NOT NULL,
  `start` varchar(10) NOT NULL,
  `end` varchar(10) NOT NULL,
  `hallname` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `book1`
--

INSERT INTO `book1` (`id`, `start`, `end`, `hallname`) VALUES
(44, '28-06-2018', '30-06-2018', 'hall-3'),
(45, '29-05-2018', '30-05-2018', 'hall-1'),
(46, '28-05-2018', '30-05-2018', 'hall-3'),
(47, '01-06-2018', '02-06-2018', 'hall-2'),
(48, '04-06-2018', '07-06-2018', 'hall-2'),
(49, '17-06-2018', '20-06-2018', 'hall-1'),
(50, '18-06-2018', '22-06-2018', 'hall-1'),
(51, '18-06-2018', '22-06-2018', 'hall-1'),
(52, '12-07-2018', '13-07-2018', 'hall-1'),
(53, '27-05-2018', '27-05-2018', 'hall-1');

-- --------------------------------------------------------

--
-- Table structure for table `cancelhall`
--

CREATE TABLE `cancelhall` (
  `id` int(10) NOT NULL,
  `hallname` varchar(20) NOT NULL,
  `start` varchar(20) NOT NULL,
  `end` varchar(20) NOT NULL,
  `firstname` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'underprocess'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cancelhall`
--

INSERT INTO `cancelhall` (`id`, `hallname`, `start`, `end`, `firstname`, `status`) VALUES
(4, 'hall-2', '08-09-2018', '12-09-2018', 'akshay', 'approve'),
(63, 'hall-2', '31-05-2018', '31-05-2018', 'ben', 'underprocess'),
(64, 'hall-1', '28-05-2018', '30-05-2018', 'emp', 'decline'),
(65, 'hall-2', '30-05-2018', '31-05-2018', 'benai', 'underprocess'),
(66, 'hall-2', '30-05-2018', '31-05-2018', 'benai', 'underprocess'),
(67, 'hall-2', '30-05-2018', '31-05-2018', 'benai', 'underprocess'),
(68, 'hall-2', '30-05-2018', '31-05-2018', 'benai', 'underprocess'),
(69, 'hall-2', '30-05-2018', '31-05-2018', 'benai', 'underprocess'),
(70, 'hall-2', '30-05-2018', '31-05-2018', 'benai', 'underprocess'),
(71, 'hall-2', '30-05-2018', '31-05-2018', 'benai', 'underprocess'),
(72, 'hall-2', '30-05-2018', '31-05-2018', 'benai', 'underprocess'),
(73, 'hall-2', '30-05-2018', '31-05-2018', 'benai', 'underprocess'),
(74, 'hall-2', '30-05-2018', '31-05-2018', 'benai', 'underprocess'),
(75, 'hall-2', '30-05-2018', '31-05-2018', 'benai', 'underprocess'),
(76, 'hall-2', '30-05-2018', '31-05-2018', 'benai', 'underprocess'),
(77, 'hall-2', '30-05-2018', '31-05-2018', 'benai', 'underprocess'),
(85, 'hall-2', '28-05-2018', '28-05-2018', 'haha', 'approve'),
(86, 'hall-2', '28-05-2018', '28-05-2018', 'haha', 'underprocess'),
(87, 'hall-1', '04-07-2018', '07-07-2018', 'john', 'underprocess');

-- --------------------------------------------------------

--
-- Table structure for table `hallregister`
--

CREATE TABLE `hallregister` (
  `id` int(20) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `start` varchar(50) NOT NULL,
  `end` varchar(50) NOT NULL,
  `hallname` varchar(20) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `phoneno` int(20) NOT NULL,
  `address` varchar(300) NOT NULL,
  `caterin` varchar(50) NOT NULL,
  `coolingsystem` varchar(50) NOT NULL,
  `attendance` int(100) NOT NULL,
  `hallfor` varchar(100) NOT NULL,
  `addon` varchar(300) NOT NULL,
  `projector` varchar(50) NOT NULL,
  `halladdress` varchar(300) NOT NULL,
  `noofdays` int(100) NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'approve'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hallregister`
--

INSERT INTO `hallregister` (`id`, `username`, `email`, `start`, `end`, `hallname`, `firstname`, `lastname`, `phoneno`, `address`, `caterin`, `coolingsystem`, `attendance`, `hallfor`, `addon`, `projector`, `halladdress`, `noofdays`, `status`) VALUES
(1, 'emp', 'emp@gmail.com', '28-06-2018', '30-06-2018', 'hall-3', 'employee', 'boss', 2147483647, 'whitefiled bangalore- 560047', 'none', 'AC', 400, 'Marriage', 'decoration', 'Yes', 'Apollo Bunder Mumbai (Bombay), Maharashtra - 400001, INDIA', 2, 'decline'),
(2, 'emp', 'emp@gmail.com', '29-05-2018', '30-05-2018', 'hall-1', 'haha', 'hehe', 2147483647, 'bsngslore', 'Snacks', 'Table Fan', 100, 'Meeting', 'nananananananana', 'NO', 'Apollo Bunder Mumbai (Bombay), Maharashtra - 400001, INDIA', 1, 'approve'),
(3, 'ben', 'ben@gmail.com', '28-05-2018', '30-05-2018', 'hall-3', 'beebaba', 'hohoh', 2147483647, 'ni where on earth', 'Lunch', 'Fan', 150, 'Conference', 'na', 'NO', 'Apollo Bunder Mumbai (Bombay), Maharashtra - 400001, INDIA', 2, 'decline'),
(4, 'ben', 'ben@gmail.com', '01-06-2018', '02-06-2018', 'hall-2', 'booboo', 'meow', 2147483647, 'jaynagar ', 'none', 'AC', 100, 'Seminar', 'flower', 'Yes', 'Apollo Bunder Mumbai (Bombay), Maharashtra - 400001, INDIA', 1, 'approve'),
(5, 'ben', 'ben@gmail.com', '04-06-2018', '07-06-2018', 'hall-2', 'hello', 'hi', 2147483647, 'uttrahalli bangalore 560047', 'Lunch', 'Fan', 451, 'Conference', 'na', 'Yes', 'Apollo Bunder Mumbai (Bombay), Maharashtra - 400001, INDIA', 3, 'approve'),
(6, 'ben', 'ben@gmail.com', '17-06-2018', '20-06-2018', 'hall-1', 'i check', 'no check', 2147483647, 'bangalore', 'Lunch', 'AC', 87, 'Seminar', 'naa', 'Yes', 'Apollo Bunder Mumbai (Bombay), Maharashtra - 400001, INDIA', 3, 'approve'),
(7, '', 'dog@gmail.com', '18-06-2018', '22-06-2018', 'hall-1', 'cat', 'mom', 2147483647, 'amazon', 'Lunch', 'Fan', 45, 'Conference', 'na', 'NO', 'Apollo Bunder Mumbai (Bombay), Maharashtra - 400001, INDIA', 4, 'approve'),
(8, 'dog', 'dog@gmail.com', '18-06-2018', '22-06-2018', 'hall-1', 'cat', 'mom', 2147483647, 'amazon', 'Lunch', 'Fan', 45, 'Conference', 'na', 'NO', 'Apollo Bunder Mumbai (Bombay), Maharashtra - 400001, INDIA', 4, 'approve'),
(9, 'kumar', 'slayerben22@gmail.com', '12-07-2018', '13-07-2018', 'hall-1', 'kjshndkf', 'mmmmmmmmmmm', 1111111111, 'bjhb', 'none', 'AC', 499, 'Seminar', 'hhh', 'Yes', 'Apollo Bunder Mumbai (Bombay), Maharashtra - 400001, INDIA', 1, 'approve'),
(10, 'kumar', 'slayerben22@gmail.com', '27-05-2018', '27-05-2018', 'hall-1', 'nothing', 'da', 2147483647, 'absjbdas', 'none', 'AC', 500, 'Seminar', 'jhbsdj', 'Yes', '26/1, Dr. Rajkumar Road, Malleswaram-Rajajinagar Bengaluru (Bangalore), Karnataka - 560055, INDIA', 0, 'decline');

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `id` int(11) NOT NULL,
  `hall_no` int(50) NOT NULL,
  `hallname` varchar(100) NOT NULL,
  `image` varchar(200) NOT NULL,
  `text` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`id`, `hall_no`, `hallname`, `image`, `text`) VALUES
(1, 0, 'hall-1', 'hall1.jpg', 'truly class hall in the country and top 10 hall across the world. with all word class facility available along with fully customize facility available, best in class interior with the finest wood. located in the heart of the city. easy to locate . please check us out . '),
(3, 0, 'hall-2', 'hall2.jpg', 'one of the biggest hall available in the country, with world class facility. great value for the money. check us out'),
(4, 0, 'hall-3', 'hall3.jpg', 'the specialty of this hall is that it is located near the beach side, both Indore and outdoor facility available , located in the silent place , with the best facility in the town. '),
(5, 0, 'hall-4', 'admin_image.jpg', ''),
(6, 0, 'register.jpg', 'hahhahaha', 'hall-5'),
(7, 0, 'register.jpg', 'hahhahaha', 'hall-5'),
(8, 0, 'hall-1.jpg', 'jshfbjasbfjasb', 'jbzsd');

-- --------------------------------------------------------

--
-- Table structure for table `images1`
--

CREATE TABLE `images1` (
  `id` int(20) NOT NULL,
  `hallname` varchar(20) NOT NULL,
  `image` varchar(300) NOT NULL,
  `text` varchar(500) NOT NULL,
  `halladdress` varchar(100) NOT NULL,
  `hallcapacity` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `images1`
--

INSERT INTO `images1` (`id`, `hallname`, `image`, `text`, `halladdress`, `hallcapacity`) VALUES
(4, 'hall-1', 'hall-1.jpg', 'hall-1 is a 5 star deluxe hotel in Bengaluru (Bangalore), India.\r\n\r\nThe hotel offers the pillar less convention center with large pre-function area for corporate events like conferences, seminars, product launches etc. and as well as marriage parties or other social events.\r\n\r\nAll  rooms and suites are offering the city view and all are designed for business and leisure traveller.\r\n\r\n\r\nLocation Advantage(s):\r\nSheraton Grand Bangalore Hotel at Brigade Gateway is centrally located, close to city a', '26/1, Dr. Rajkumar Road, Malleswaram-Rajajinagar Bengaluru (Bangalore), Karnataka - 560055, INDIA', 500),
(7, 'hall-3', 'hall-3.jpeg', 'Hall-3 Sahara Star is a 5 star deluxe hotel in Mumbai (Bombay), India.\r\n\r\nThe hall is offering one of the Mumbaiâ€™s largest pillars-less multi-purpose event hall along with different sizes of banquet halls and meeting rooms.\r\n\r\nAll rooms and suites are offering a serene view of the tropical lagoon or a panoramic view of the city.\r\n\r\nManaged by: Sahara Hospitality\r\n\r\nLocation Advantage(s):\r\nHotel Sahara Star is strategically located only 1 km. away from Chhatrapati Shivaji International Airport ', 'Opp. Domestic Airport Mumbai (Bombay), Maharashtra - 400099, India', 500),
(8, 'hall-2', 'hall-2.jpg', 'hall-2 is a 5 star deluxe hotel in Bengaluru (Bangalore), India.\r\n\r\nThe hotel offers the pillar less convention center with large pre-function area for corporate events like conferences, seminars, product launches etc. and as well as marriage parties or other social events.\r\n\r\nAll  rooms and suites are offering the city view and all are designed for business and leisure traveller.\r\n\r\n\r\nLocation Advantage(s):\r\nSheraton Grand Bangalore Hotel at Brigade Gateway is centrally located, close to city a', 'Apollo Bunder Mumbai (Bombay), Maharashtra - 400001, INDIA', 500);

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` int(10) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL,
  `start` varchar(50) NOT NULL,
  `end` varchar(50) NOT NULL,
  `hallname` varchar(50) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `phoneno` int(13) NOT NULL,
  `address` varchar(100) NOT NULL,
  `caterin` varchar(50) NOT NULL,
  `coolingsystem` varchar(50) NOT NULL,
  `attendance` int(20) NOT NULL,
  `hallfor` varchar(50) NOT NULL,
  `addon` varchar(50) NOT NULL,
  `halladdress` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  `message` varchar(50) NOT NULL,
  `paymentstatus` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `username`, `email`, `password`, `start`, `end`, `hallname`, `firstname`, `lastname`, `phoneno`, `address`, `caterin`, `coolingsystem`, `attendance`, `hallfor`, `addon`, `halladdress`, `status`, `message`, `paymentstatus`) VALUES
(40, 'emp', 'emp@gmail.com', '', '08-09-2018', '12-09-2018', 'hall-2', 'akshay', 'n', 1231234451, '#123', 'none', 'AC', 54, 'Marriage', 'drinks', '', '', '', ''),
(41, 'emp', 'emp@gmail.com', '', '26-07-2018', '30-07-2018', 'hall-1', 'employee', 'the  great', 2147483647, 'jadsf', 'none', 'AC', 41, 'Marriage', 'tandoori', '', '', '', ''),
(42, 'ben', 'ben@gmail.com', '', '30-05-2018', '31-05-2018', 'hall-2', 'benai', 'kumar', 2147483647, 'jasbd', 'none', 'AC', 44, 'Marriage', '8pm', '', '', '', ''),
(43, 'ben', 'ben@gmail.com', '', '31-05-2018', '31-05-2018', 'hall-1', 'this one', 'last one', 2147483647, '', 'none', 'AC', 222, 'Marriage', 'na', '', '', '', ''),
(44, 'ben', 'ben@gmail.com', '', '28-05-2018', '28-05-2018', 'hall-2', 'haha', 'hoooo', 2147483647, 'jzd', 'none', 'AC', 100, 'Marriage', 'nothing', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `userregister`
--

CREATE TABLE `userregister` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userregister`
--

INSERT INTO `userregister` (`id`, `name`, `email`, `password`) VALUES
(61, 'benai', 'benaikumar@gmail.com', 'ben123'),
(120, 'ben', 'ben@gmail.com', '123'),
(132, 'vaishu', 'vaishu@gmail.com', '123'),
(133, 'hi', 'hi@gmail.com', '123'),
(134, 'ljdnf', 'hehe@gmail.com', '123'),
(135, 'hello', 'hello@gmail.com', '123'),
(136, 'hello1', 'hello1@gmail.com', '123'),
(137, 'ok', 'ok@gmail.com', '123'),
(138, 'hi1', 'hi@gmail.com', '123'),
(139, 'hi1', 'hi@gmail.com', '1234'),
(140, 'hi111', 'hi@gmail.com', '111'),
(142, 'check', 'check@gmail.com', '123'),
(143, 'jbsd', 'jabs@gmail.com', 'ajsdb'),
(144, 'ooooooooo', 'oooooooo@gmail.com', '1212'),
(145, 'benai', 'slayerben222@gmil.com', '1212'),
(146, 'benai', 'slayerben222222@gmil.com', '12'),
(147, 'benai', 'slayerben22@gmail.com', '1234'),
(148, 'kumar', 'kumar@gmail.com', '123'),
(149, 'ok', 'okokok@gmail.com', '12'),
(150, 'ookok', 'ok@gmail.com', '123'),
(151, 'ok', 'hahahahahaah@gmail.com', '11'),
(152, 'emp', 'emp@gmail.com', '123'),
(153, 'aksh', 'akshayn.1rx16mcao5@gmail.com', '123');

-- --------------------------------------------------------

--
-- Table structure for table `userregister1`
--

CREATE TABLE `userregister1` (
  `id` int(20) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(200) NOT NULL,
  `isemailconfirm` tinyint(4) NOT NULL DEFAULT '0',
  `token` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userregister1`
--

INSERT INTO `userregister1` (`id`, `username`, `email`, `password`, `isemailconfirm`, `token`) VALUES
(1, 'dog', 'dog@gmail.com', '123', 1, 'vBplqJ'),
(2, 'emp', 'emp@gmail.com', '123', 1, 'IfVrla'),
(3, 'kumar', 'slayerben22@gmail.com', '123', 1, 'SekfHn'),
(5, 'haha', 'haha@gmail.com', '123', 1, 'abcdHw'),
(6, '', 'vavavav@gmail.com', '11', 0, 'ktInCv');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `book1`
--
ALTER TABLE `book1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cancelhall`
--
ALTER TABLE `cancelhall`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hallregister`
--
ALTER TABLE `hallregister`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `images1`
--
ALTER TABLE `images1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userregister`
--
ALTER TABLE `userregister`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userregister1`
--
ALTER TABLE `userregister1`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `book1`
--
ALTER TABLE `book1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT for table `cancelhall`
--
ALTER TABLE `cancelhall`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=88;

--
-- AUTO_INCREMENT for table `hallregister`
--
ALTER TABLE `hallregister`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `images1`
--
ALTER TABLE `images1`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `userregister`
--
ALTER TABLE `userregister`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=154;

--
-- AUTO_INCREMENT for table `userregister1`
--
ALTER TABLE `userregister1`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
